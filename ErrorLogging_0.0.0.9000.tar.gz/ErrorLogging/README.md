# ErrorLogging

<!-- badges: start -->
<!-- badges: end -->

The goal of ErrorLogging is to ...

## Installation

You can install the released version of ErrorLogging from [CRAN](https://CRAN.R-project.org) with:

``` r
install.packages("ErrorLogging")
```

## Example

This is a basic example which shows you how to solve a common problem:

``` r
library(ErrorLogging)
## basic example code
```

