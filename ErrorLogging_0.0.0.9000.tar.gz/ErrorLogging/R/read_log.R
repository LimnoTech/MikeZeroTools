#' Title
#'
#' @param filepath
#'
#' @return
#' @export
#'
#' @examples
read_log <- function(filepath) {
  c(filepath, readLines(filepath))
}

# C:/Users/bcrary/Desktop/Projects/DONRDS/ErrorLogging/TEST_20200127_FBO_4B_Reg1560_75.2_CFLOutput.log
# TEST_20200127_FBO_4B_Reg1560_75.2_CFLOutput.log
